package com.harrywitriyono.myprofilev1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;

public class Main3Activity extends AppCompatActivity {
    WebView webviewsaya;
    WebSettings websettingsaya;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        webviewsaya = (WebView) findViewById(R.id.webview1);
        websettingsaya = webviewsaya.getSettings();
        webviewsaya.setWebViewClient(new WebViewClient());
        webviewsaya.loadUrl("http://harrywitriyono.com");
    }
}
